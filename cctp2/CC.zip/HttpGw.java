/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cctp2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
/**
 *
 * @author pedro
 */

public class HttpGw {
    
    static Set<Tuple<InetAddress, Integer>> servidores = new TreeSet<>();
    
    static class Authenticator implements Runnable {
        DatagramSocket socket;
        
        public Authenticator (DatagramSocket sock) {
            this.socket = sock;
        }
        
        public Boolean valida (String codigo) {
            return codigo.charAt(0) == 'C' && codigo.charAt(1) == 'C' && codigo.charAt(2) == '2' && codigo.charAt(3) == '1';
        }
        
        public void run() {
            try {
                while (true) {
                    int porta;
                    byte[] buf = new byte[1024];
                    DatagramPacket pacote = new DatagramPacket(buf, buf.length);
                    String recebido;
                    
                    socket.receive(pacote);
                    
                    InetAddress address = pacote.getAddress();
                    porta = pacote.getPort();
                    
                    recebido = new String(pacote.getData(), 0, pacote.getLength());
                    
                    if (valida(recebido)) {
                        System.out.println("Validado com pass " + recebido);
                        servidores.add(new Tuple<>(address, porta));
                        
                    } else 
                        System.out.println("Não validado com pass " + recebido);
                    for (Tuple<InetAddress, Integer> entrada : servidores)
                            System.out.println("Servidor: " + entrada.getFirst() + " " + entrada.getSecond());
                }
            } catch (Exception e) {}
        }
    }
    static class ChunkWorker implements Runnable{
        Socket socket;

        public ChunkWorker (Socket sock) {
            socket = sock;
        }

        public void run() {
            try {
                BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                //System.out.println("Pedido: " + br.readLine());
                String pedido = br.readLine();
                String[] parametros = pedido.split(" ");
                System.out.println("Pedido: " + pedido);
                System.out.println("Ficheiro: " + parametros[1]);
                System.out.println("Ip e porta: " + br.readLine().split(" ")[1]);


            } catch (IOException e) {}

        }
    }

    public static void main (String[] args) throws SocketException, UnknownHostException, IOException {
        ServerSocket serverSock = new ServerSocket(8880);
        Socket sock;
        DatagramSocket s = new DatagramSocket(9999, InetAddress.getByName("localhost"));
        Thread t = new Thread(new Authenticator(s));
        t.start();
        
        while (true) {
            sock = serverSock.accept();
            Thread worker = new Thread(new ChunkWorker(sock));
            
            worker.start();
            /*
            DatagramSocket socket = new DatagramSocket();
            InetAddress address = InetAddress.getByName("localhost");
            String message = "o Pedro ama a Sara";


            byte[] buf = message.getBytes();
            DatagramPacket pacote = new DatagramPacket(buf, buf.length, address, 8888);
            socket.send(pacote);

            socket.receive(pacote);

            String recebido = new String(pacote.getData(), 0, pacote.getLength());
            System.out.println("É verdade que: " + recebido);

            socket.close();*/
        }
    }
}
