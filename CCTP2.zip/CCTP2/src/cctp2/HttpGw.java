/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cctp2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Map;
import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.nio.file.Files;
import java.util.AbstractMap;
import java.util.LinkedList;
import java.util.Map.Entry;
import java.util.Queue;
import java.util.Stack;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;
/**
 *
 * @author pedro
 */

public class HttpGw {
    static int chunkSize = 1024;
    static Queue<Map.Entry<InetAddress, Integer>> servidores = new LinkedList<>();
    
    static class chunkGetter implements Runnable {
        DatagramSocket socket;
        ReentrantLock chunkLock;
        ReentrantLock serverLock;
        Condition termina;
        Condition c;
        InetAddress servidor;
        int porta;
        Stack<Integer> chunkStack;
        String nomeFicheiro;
        int chunkTot = 0;
        int tamanho;
        byte[] ficheiro;
        
        
        public chunkGetter (byte[] ficheiro, int tamanho, int chunks, String nomeFicheiro, ReentrantLock serverLock, 
                ReentrantLock chunkLock, Condition termina, Condition c, Entry<InetAddress, Integer> e, Stack<Integer> chunkStack) throws SocketException {
            this.socket = new DatagramSocket();
            this.serverLock = serverLock;
            this.chunkLock = chunkLock;
            this.c = c;
            this.servidor = e.getKey();
            this.porta = e.getValue();
            this.nomeFicheiro = nomeFicheiro;
            this.chunkStack = chunkStack;
            this.chunkTot = chunks;
            this.tamanho = tamanho;
            this.ficheiro = ficheiro;
            this.termina = termina;
        }
        
        public void devolveServidor() {
            try {
                serverLock.lock();
                servidores.add(new AbstractMap.SimpleEntry<InetAddress, Integer>(servidor, porta));
            } finally {
                serverLock.unlock();
            }
        }
        
        public int haChunks () {
            try {
                chunkLock.lock();
                if (chunkStack.isEmpty())
                    return -1;
                return chunkStack.pop();
            } finally {
                chunkLock.unlock();
            }
        }
        
        public void run () {
            int chunkPiece;
            try {
                DatagramSocket dataSocket = new DatagramSocket();

                while ((chunkPiece = haChunks()) >= 0) {
                    byte[] buf = ("Chunk " + chunkPiece + " " + nomeFicheiro + " ").getBytes();
                    DatagramPacket pacote = new DatagramPacket(buf, buf.length, servidor, porta);

                    //pede os dados desse chunk
                    dataSocket.send(pacote);
                    buf = new byte[1500];
                    pacote = new DatagramPacket(buf, buf.length);
                    dataSocket.receive(pacote);
                    //meter locks e conds numa struct
                    
                    if (chunkTot == chunkPiece) {
                        System.arraycopy(buf, 0, ficheiro, chunkPiece*chunkSize, tamanho);
                    }
                    else System.arraycopy(buf, 0, ficheiro, chunkPiece*chunkSize, chunkSize);
                    
                    if (chunkPiece == 0) {
                        try {
                            serverLock.lock();
                            termina.signalAll();
                        } finally {
                            serverLock.unlock();
                        }
                    }
                }
                
            } catch (IOException e) {}
            devolveServidor();
        }
    }
    
    static class Authenticator implements Runnable {
        DatagramSocket socket;
        ReentrantLock lock;
        Condition c;
        
        public Authenticator (DatagramSocket sock, ReentrantLock l, Condition c) {
            this.socket = sock;
            this.lock = l;
            this.c = c;
        }
        
        public Boolean valida (String codigo) {
            return codigo.substring(0, 4).equals("CC21");
        }
        
        public void enviaAuth (InetAddress address, int porta) throws IOException{
            Map.Entry<InetAddress, Integer> t = new AbstractMap.SimpleEntry<>(address, porta);
            byte[] buf;
            DatagramPacket pacote;
            
            try {
                lock.lock();
                servidores.add(t);
                buf = ("Autenticado").getBytes();
                pacote = new DatagramPacket(buf, buf.length, address, porta);
                socket.send(pacote);
                c.signalAll();
            } finally {
                lock.unlock();
            }
        }
        
        public void run() {
            try {
                while (true) {
                    int porta;
                    byte[] buf = new byte[1024];
                    DatagramPacket pacote = new DatagramPacket(buf, buf.length);
                    String recebido;
                    
                    socket.receive(pacote);
                    
                    InetAddress address = pacote.getAddress();
                    porta = pacote.getPort();
                    
                    recebido = new String(pacote.getData(), 0, pacote.getLength());
                    if (valida(recebido)) {
                        enviaAuth(address, porta);
                        
                    } else 
                        System.out.println("Não validado com pass " + recebido);
                    
                    System.out.println("\nLista de servidores:");
                    for (Map.Entry<InetAddress, Integer> entrada : servidores)
                            System.out.println("Servidor: " + entrada.getKey() + " " + entrada.getValue());
                    
                }
            } catch (Exception e) {}
        }
    }
    
    static public Boolean validaFich (String s) {
        return s.substring(0, 2).equals("OK");
    }
    
    
    static class ChunkWorker implements Runnable{
        Socket socket;
        ReentrantLock serverLock;
        DatagramSocket dataSocket;
        Condition c;
        
        public ChunkWorker (Socket sock, ReentrantLock l, Condition c) {
            this.socket = sock;
            this.serverLock = l;
            this.c = c;
        }
        
        public Map.Entry<InetAddress, Integer> procuraServidor () {
            Map.Entry<InetAddress, Integer> serv = null;

            try {
                serverLock.lock();
                if (servidores.size() > 0)
                    serv = servidores.iterator().next();
                while (serv == null) {
                    System.out.println("No servers available, sleeping until one is added");
                    c.await();

                    if (servidores.size() > 0)
                        serv = servidores.iterator().next();
                }
                servidores.remove(serv);
            } catch (Exception e) {
            } finally {
                serverLock.unlock();
            } 
        
            return serv;
        }
        
        public Boolean peekChunks (Stack<Integer> chunkStack, ReentrantLock chunkLock) {
            try {
                chunkLock.lock();
                return !chunkStack.isEmpty();
            } finally {
                chunkLock.unlock();
            }
        }
        
        public void run() {
            try {
                BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                DataOutputStream out = new DataOutputStream(new BufferedOutputStream(socket.getOutputStream()));
                
                
                Map.Entry<InetAddress, Integer> serv = null;
                DatagramPacket pacote;
                int chunk = 0;
                this.dataSocket = new DatagramSocket();
                String pedido = br.readLine();
                String[] parametros = pedido.split(" ");
                
                String nomeFicheiro = parametros[1].substring(1);
                byte[] buf = ("Getmeta" + pedido).getBytes();
                
                serv = procuraServidor();
                
                //Servidor é encontrado e colocado em serv
                
                pacote = new DatagramPacket(buf, buf.length, serv.getKey(), serv.getValue());
                
                //Pedido de metadados ao servidor
                
                dataSocket.send(pacote);
                
                buf = new byte[1500];
                pacote = new DatagramPacket(buf, buf.length);
                dataSocket.receive(pacote);
                
                //adicionar verificação se o pacote é o que devia ser, e devolve o servidor à lista
                servidores.add(serv);
                
                String mensagem = new String (pacote.getData());
                String[] campos = mensagem.split(" ");
               
                if (validaFich(mensagem)) {
                    int num = Integer.valueOf(campos[1]);
                    int servers = 0;
                    int tentativas = 0;
                    ReentrantLock chunkLock = new ReentrantLock();
                    Condition termina = serverLock.newCondition();
                    
                    Stack<Integer> chunkStack = new Stack<Integer>();
                    
                    System.out.println("Cool O ficheiro " + nomeFicheiro + " tem " + num + " bytes");
                    Integer tamanho = Integer.valueOf(num);
                    byte[] ficheiro = new byte[tamanho];
                    
                    while (tamanho > chunkSize) {
                        chunkStack.push(chunk);
                        chunk++;
                        tamanho -= chunkSize;
                    }
                    
                    chunkStack.push(chunk);
                    
                    System.out.println(chunkStack);
                    
                    try {
                        serverLock.lock();
                    
                    while (peekChunks(chunkStack, chunkLock)) {
                        while (tentativas <= 4 && servers <= chunk && servers <= 2 && peekChunks(chunkStack, chunkLock)) {
                            tentativas++;
                                    
                            try {
                                serverLock.lock();
                                if (servidores.size() > 0) {
                                    serv = procuraServidor();
                                    servers++;
                                    Thread chunkServer = new Thread(new chunkGetter(ficheiro, tamanho, chunk,nomeFicheiro,
                                    serverLock, chunkLock, termina,  c, serv, chunkStack));
                                    chunkServer.start();
                                }
                            } finally {
                                serverLock.unlock();
                            }
                            
                            if (servers == 0) {
                                procuraServidor();
                                servers++;
                            }
                        }
                        System.out.println("Ainda não são 15");
                        termina.await();
                        System.out.println("Mas juntos podemos lá chegar");
                                             
                    }
                    } catch (InterruptedException e) {
                    }finally {
                        serverLock.unlock();
                    }
                    File fich = new File(parametros[1].substring(1));
                    
                         
                    out.write("HTTP/1.1 200 OK\r\n".getBytes());
                    out.write(("Content-Type: " + Files.probeContentType(fich.toPath()) + "\r\n").getBytes());
                    out.write(("Content-Length: " + ficheiro.length + "\r\n\r\n").getBytes());                    
                    out.write(ficheiro);
                    out.flush();

                    System.out.println("Ficheiro: " + parametros[1].substring(1));
                    System.out.println("Tipo: " + Files.probeContentType(new File (parametros[1].substring(1)).toPath()));
                    
// Set para guardar os chunks e isto ficar à espera que estejam prontos
                    /*
                    while (chunkSet.size() > 0) {
                        chunkWait.await();
                    }
                    
                    

                    // TESTE TIRAR
                    
                    */
                } else {
                    System.out.println("FODEU! O ficheiro " + parametros[1] + " tem " + mensagem.substring(3) + " bytes");
                }
                
                out.close();
                    
            } catch (IOException e) {}

        }
    }

    public static void main (String[] args) throws SocketException, UnknownHostException, IOException {
        ServerSocket serverSock = new ServerSocket(8080);
        Socket sock;
        ReentrantLock lock = new ReentrantLock();
        Condition condition = lock.newCondition();
        
        DatagramSocket s = new DatagramSocket(9999, InetAddress.getByName("localhost"));
        Thread t = new Thread(new Authenticator(s, lock, condition));
        t.start();
        
        while (true) {
            sock = serverSock.accept();
            System.out.println("blablabla");
            Thread worker = new Thread(new ChunkWorker(sock, lock, condition));
            
            worker.start();
        }
    }
}
