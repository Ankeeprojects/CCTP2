/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cctp2;

import java.io.*;
import java.nio.file.*;
import java.lang.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.file.attribute.BasicFileAttributes;


/**
 *
 * @author pedro
 */

public class CCTP2 {

    /**
     * @param args the command line arguments
     */
    
    public static Boolean quermeta(String mensagem) {
        return mensagem.substring(0, 7).equals("Getmeta");
    }
    
    public static Boolean querdados(String mensagem) {
        return mensagem.substring(0,5).equals("Chunk");
    }
    
    public static Boolean autentica (DatagramSocket socket) throws IOException {
        byte[] buffer = new byte[1000];
        DatagramPacket pacote = new DatagramPacket(buffer, buffer.length);
        
        byte[] bufi = ("CC21").getBytes();
        socket.send(new DatagramPacket(bufi, bufi.length, InetAddress.getByName("localhost"), 9999));
        
        //TODO verificar se o pacote recebido é mesmo para autenticar
        socket.receive(pacote);
        
        System.out.println("Fui autenticado com a mensagem: " + new String (pacote.getData()) + 
                " endereço e porta " + pacote.getAddress() + ":" + pacote.getPort());
        
        return true;
    }
    
    public static void main(String[] args) throws Exception {
        DatagramSocket socket = new DatagramSocket();
        byte[] buffer = new byte[1500];
        String[] campos;
        DatagramPacket pacote;
        if (autentica(socket)) {
            while (true) {
                byte[] buf = new byte[1500];
                pacote = new DatagramPacket(buf, buf.length);
                socket.receive(pacote);
                InetAddress address = pacote.getAddress();
                int porta = pacote.getPort();
                String mensagem = new String (pacote.getData());
                System.out.println("Recebi isto: " + mensagem);

                if (quermeta(mensagem)) {
                    campos = mensagem.split(" ");
                    File f = new File (campos[1].substring(1));

                    if(f.exists())
                        System.out.println("Ficheiro " + campos[1] + " tem " + f.length() + " bytes.");
                    else
                        System.out.println("Tentei abrir " + campos[1] + " mas não deu");

                    buf = ("OK " + f.length() + " ").getBytes();
                    pacote = new DatagramPacket(buf, buf.length, address, porta );
                    socket.send(pacote);
                } else if (querdados(mensagem)) {
                    System.out.println(mensagem);
                    campos = mensagem.split(" ");

                    int quantos;
                    int chunk = Integer.valueOf(campos[1].replaceAll("\\D+","")) * 1024;
                    File f = new File(campos[2]);
                    FileInputStream inputStream = new FileInputStream(f);
                    
                    inputStream.skipNBytes(chunk);
                    if (f.length() > chunk + 1024)
                        quantos = 1024;
                    else quantos = (int) f.length() - chunk;

                    System.out.println("O tamanho do chunk é " + quantos);

                    byte[] dados = new byte[quantos];
                    inputStream.read(dados, 0, quantos);
                    inputStream.close();
                    pacote = new DatagramPacket(dados, quantos, address, porta);
                    socket.send(pacote);
                }
                /*
                pacote = new DatagramPacket(buf, buf.length, address, porta);
                String recebido = new String(pacote.getData(), 0, pacote.getLength());

                System.out.println(recebido);
                socket.send(pacote);


                int tamanhoChunk = 1024;
                File in = new File("Aula1.c");
                FileInputStream inputStream;
                String nomeFicheiro = "Aula1.c";
                String nome;
                FileOutputStream filep;

                int fileSize = (int)in.length();
                int chunks = 0; 
                byte[] chunk;
                int quantos = tamanhoChunk;
                int lidos;
                int accum = 0;
                try {
                    inputStream = new FileInputStream(in);
                    while (accum < fileSize) {
                        if ((fileSize - accum) < tamanhoChunk) 
                            quantos = fileSize - accum;

                        //System.out.println("quantos: " + quantos );
                        chunk = new byte[quantos];
                        //mudar offset para depois

                        lidos = inputStream.read(chunk, 0, quantos);
                        accum += lidos;

                        nome = nomeFicheiro + ".part" + chunks;
                        chunks++;
                        System.out.println(nome);
                        filep = new FileOutputStream(new File(nome));
                        filep.write(chunk);
                        filep.flush();
                        filep.close();
                    }
                    inputStream.close();
                }  catch (Exception e) {}*/
           }
        } else {
            System.out.println("Não foi possível autenticar com servidor HttpGw, tente novamente mais tarde.");
        }
    }
}
    
